package entrega6;
public class Entrega6 {
    public static void main(String[] args) {
        int n = 41;     //participantes
        int m = 2;      //cada cuantos (para este problema en particular es cada 2)

        int sobreviviente = lugar(n, m);

        System.out.println("Josefo tiene que ser el: " + sobreviviente);
    }
    
    static int lugar(int n, int m) {
        int resultado = 0;

        for (int i = 2; i <= n; i++) {
            resultado = (resultado + m) % i;
        }

        return resultado + 1; 
    } 
    
}
