package estilosdeprogramación;
import java.util.ArrayDeque;
import java.util.Queue;

class Mover
{
    int x, y;   //variables de movimiento
 
    public Mover(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
}

public class EstilosDeProgramación {
        private static final int[] ren = { -1, -1, -1, 0, 1, 0, 1, 1 }; //movimientos hacia la izquierda y derecha
        private static final int[] col = { -1, 1, 0, -1, -1, 1, 0, 1 }; //movimientos hacia arriba y abajo
        
    public static boolean islas(int[][] mat, int x, int y, boolean[][] procesado){
        return (x >= 0 && x < procesado.length) && (y >= 0 && y < procesado[0].length)
                && mat[x][y] == 1 && !procesado[x][y];
    }
    
     public static void paso(int[][] mat, boolean[][] procesado, int i, int j)
    {
        Queue<Mover> q = new ArrayDeque<>();
        q.add(new Mover(i, j));
 
        procesado[i][j] = true;
 
        while (!q.isEmpty())
        {

            int x = q.peek().x;
            int y = q.peek().y;
            q.poll();
 
            for (int k = 0; k < ren.length; k++)
            {

                if (islas(mat, x + ren[k], y + col[k], procesado)) //si no hay un 1 o ya lo paso lo omite
                {
                    procesado[x + ren[k]][y + col[k]] = true;
                    q.add(new Mover(x + ren[k], y + col[k]));
                }
            }
        }
    }
     
    public static int contarIslas(int[][] mapa)
    {
        // caso base
        if (mapa == null || mapa.length == 0) {
            return 0;
        }
 
        // matriz `M × N`
        int M = mapa.length;
        int N = mapa[0].length;
 
        // almacena si una celda es procesada o no
        boolean[][] procesado = new boolean[M][N];
 
        int isla = 0;
        for (int i = 0; i < M; i++)
        {
            for (int j = 0; j < N; j++)
            {
                // inicia paso desde cada nodo sin procesar y
                // incrementa el número de islas
                if (mapa[i][j] == 1 && !procesado[i][j])
                {
                    paso(mapa, procesado, i, j);
                    isla++;
                }
            }
        }
 
        return isla;
    }
        
    public static void main(String[] args) {
        int[][] mapa={                                                  //Matriz del mapa dado
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0},
                        {0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0},
                        {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0},
                        {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0},
                        {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0},
                        {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };
        System.out.println("Islas totales " + contarIslas(mapa));
    }
    
}
